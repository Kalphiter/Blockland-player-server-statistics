
To see the graphs, visit https://kalphiter.github.io/Blockland-statistics/blockland-graph.htm

Credits for data:
(master server list collection)
	Kalphiter - late 2009 to mid 2014
	Hammereditor - early 2015 to mid 2016
	Pecon - late 2016 to present

Other credits:
	Kalphiter - graph, server list recording code
			This grew out of a graph I used to have of the last 24 hours' activity


http://fiddle.jshell.net/x9Pjv/16/
(original home of the graph, last updated June 3rd, 2014)
